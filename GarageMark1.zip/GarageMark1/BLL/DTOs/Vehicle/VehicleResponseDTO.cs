﻿using GarageMark1.BLL.DTOs.User;
using System.ComponentModel.DataAnnotations.Schema;

namespace GarageMark1.BLL.DTOs.Vehicle
{
    public class VehicleResponseDTO
    {
        public int VehicleId { get; set; }
        public string VehiclePlateNumber { get; set; } = null!;
        public string? VehicleDescription { get; set; }
        public int VehicleOwnerId { get; set; }
       
        public string VehicleOwnerUsername { get; set;}
        
        

       
    }
}
