import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { Navbar } from "react-bootstrap";
import { NavDropdown } from "react-bootstrap";
import { Nav } from "react-bootstrap";
import { useState } from "react";
import { useEffect } from "react";
import { ToastContainer, toast } from 'react-toastify';

const Head = () => {
  const navigate = useNavigate()




  const [navbarUserIsLogged, setnavbarUserIsLogged] = useState(false);
  useEffect(() => {
    (async () => {
      const result = localStorage.getItem('id');
      if (result) {
        setnavbarUserIsLogged(true);
      }
    })();
  }, [navbarUserIsLogged]);

  const handleLogout = async () => {
    localStorage.clear();
   
    navigate("/")
    window.location.reload();
    toast.success("Logged Out Successfully");
  }

  return (
    //   <nav class="navbar navbar-expand-lg navbar-light bg-light">
    //   <a class="navbar-brand" >GarageMark1</a>
    //   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    //     <span class="navbar-toggler-icon"></span>
    //   </button>

    //   <div class="collapse navbar-collapse" id="navbarSupportedContent">
    //     <ul class="navbar-nav mr-auto">
    //       <li class="nav-item active">
    //       <Link to="/Test" className="nav-link">   Home <span class="sr-only">(current)</span></Link>
    //       </li>
    //       <li class="nav-item">
    //         <a class="nav-link" >About</a>
    //       </li>


    //     </ul>


    //   </div>
    // </nav>
    // <header>
    //   <nav className="navbar navbar-expand-lg navbar-light bg-danger">
    //     <div className="container-fluid">
    //       <a className="navbar-brand" href="#" >GarageMark1</a>
    //       {!navbarUserIsLogged ? (
    //         <div style={{ marginLeft: '80%' }} className="collapse navbar-collapse " id="navbarNav">
    //           <ul className="navbar-nav">
    //             {/* <button className="btn btn-lg btn-success">Login</button> */}
    //           </ul>
    //         </div>

    //       ) : (
    //         <div class="dropdown mt-2 " style={{ marginRight: '80px' }}>
    //           <Nav.Item href="#action1">Home</Nav.Item>
    //           <Navbar.Toggle aria-controls="navbar-dark-example" />
    //           <Navbar.Collapse id="navbar-dark-example">
    //             <NavDropdown
    //               id="nav-dropdown-dark-example"

    //               menuVariant="dark"
    //             >
    //               <NavDropdown.Item href="#action/3.1">Orders</NavDropdown.Item>

    //               {/* <NavDropdown.Item href="#action/3.2" data-toggle="modal" data-target="#cart">My Cart</NavDropdown.Item> */}
    //               <NavDropdown.Item href="#action/3.3">Setting</NavDropdown.Item>
    //               <NavDropdown.Item onClick={handleLogout} href="#action/3.3" >Logout</NavDropdown.Item>
    //             </NavDropdown>

    //           </Navbar.Collapse>
    //         </div>

    //       )}
    //     </div>
    //   </nav>

    // </header>
    <>
    <ToastContainer/>
    <Navbar bg="dark" variant="dark" style={{ backgroundColor: '#3498db' }}>
      <Navbar.Brand style={{ color: 'white', fontFamily: 'Roboto' }} href=""> &nbsp; GarageMark1</Navbar.Brand>

      <Navbar.Brand style={{ color: 'white', fontFamily: 'Roboto' }} href="/about">&nbsp; < span >About Us</span></Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ml-auto ">
          {navbarUserIsLogged ? (
            <>
              <Nav.Link onClick={() => {
                   
                if(localStorage.getItem("id")!=71){
                  console.log(localStorage.getItem("id"))
                navigate('/Home')
               
                }
                else{
                  navigate('/admin')
                }
                
                }} style={{ color: 'white', fontFamily: 'Roboto', fontSize: '1.25rem' }} > &nbsp; Dashboard</Nav.Link>
              <Nav.Link href="#" style={{ color: 'white', fontFamily: 'Roboto', fontSize: '1.25rem' }} onClick={handleLogout}>LogOut &nbsp; &nbsp;</Nav.Link>
            </>
          ) : (
            <>


             
              <Nav.Link href="#" >  &nbsp;  &nbsp;</Nav.Link>
              {/* Add more login-related options here */}

            </>
          )}
        </Nav>
      </Navbar.Collapse>
    </Navbar>
    </>
  )
}
export default Head;