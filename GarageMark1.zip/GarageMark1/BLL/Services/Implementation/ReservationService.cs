﻿using AutoMapper;
using GarageMark1.BLL.DTOs.Reservation;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories.Interfaces;

namespace GarageMark1.BLL.Services.Implementation
{
    public class ReservationService : IReservationService
    {
        private readonly IRepositoryWrapper repositoryWrapper;
        private readonly IMapper mapper;

        public ReservationService(IRepositoryWrapper repositoryWrapper, IMapper mapper)
        {
            this.repositoryWrapper = repositoryWrapper;
            this.mapper = mapper;
        }

        public async Task<ReservationResponseDTO> Add(ReservationRequestDTO requestDTO)
        {
            var product = mapper.Map<TblReservation>(requestDTO);
            var productResponse = await repositoryWrapper.ReservationRepository.CreateAsync(product);
            await repositoryWrapper.SaveAsync();
            var result = mapper.Map<ReservationResponseDTO>(productResponse);
            return result;
        }

        public async Task<bool> Delete(int id)
        {
            var data = await repositoryWrapper.ReservationRepository.GetById(id);


            var res = mapper.Map<TblReservation>(data);
            if (res != null)
            {
                await repositoryWrapper.ReservationRepository.DeleteAsync(data);
                await repositoryWrapper.SaveAsync();
                return true;

            }
            else
            {
                return false;
            }
        }

        public Task<IEnumerable<ReservationResponseDTO>> GetAll()
        {
            throw new NotImplementedException();
        }

        public async Task<ReservationResponseDTO> GetById(int id)
        {
            var data = await repositoryWrapper.ReservationRepository.GetById(id);
            var res = mapper.Map<ReservationResponseDTO>(data);
            return res;
        }

        public async Task<ReservationResponseDTO> Update(int id, ReservationRequestDTO res)
        {
            var f = mapper.Map<TblReservation>(res);
            f.ReservationId = id;
            var v = await repositoryWrapper.ReservationRepository.UpdateAsync(id, f);
            await repositoryWrapper.SaveAsync();
            var k = mapper.Map<ReservationResponseDTO>(v);

            return k;
        }
    }
}
