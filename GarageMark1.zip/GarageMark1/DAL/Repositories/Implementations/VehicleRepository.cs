﻿using GarageMark1.DAL.DBContext;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Server.IIS.Core;
using Microsoft.EntityFrameworkCore;

namespace GarageMark1.DAL.Repositories.Implementations
{
    public class VehicleRepository : RepositoryBase<TblVehicle>, IVehicleRepository
    {
        private readonly GarageContext _garageContext;
        public VehicleRepository(GarageContext dbContext) : base(dbContext)
        {
            _garageContext = dbContext;

        }
      
        public async Task<string> GetName(int id)
        {
            try
            {
                var e = await _garageContext.TblVehicles.Include("VehicleOwner").Where(i => i.VehicleId == id).ToListAsync();

                var t = e.FirstOrDefault().VehicleOwner.Username;
                return t;
            }
            catch(Exception ex) { return "Data Not Found";
            }
           
        }
        public async Task<List<string>> GetVehicleNames(int id)
        {
            try
            {
                var data = await _garageContext.TblVehicles.Include("VehicleOwner").Where(i => i.VehicleOwnerId == id).ToListAsync();
                List<string> result = new List<string>();
                foreach (var i in data)
                {
                    result.Add(i.VehicleDescription);
                }
                return result;
            }
            catch(Exception ex)
            {
                List<string> res = new List<string>();
                res.Add("Id Not Found");
                return res;
            }
        }
    }
}
