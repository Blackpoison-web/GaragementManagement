﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GarageMark1.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TblParkingSlots",
                columns: table => new
                {
                    SlotId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FloorNumber = table.Column<int>(type: "int", nullable: false),
                    SlotNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsReserved = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblParkingSlots", x => x.SlotId);
                });

            migrationBuilder.CreateTable(
                name: "TblUsers",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Username = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsAdmin = table.Column<bool>(type: "bit", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblUsers", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "TblVehicles",
                columns: table => new
                {
                    VehicleId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VehiclePlateNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    VehicleDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    VehicleOwnerId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblVehicles", x => x.VehicleId);
                    table.ForeignKey(
                        name: "FK_TblVehicles_TblUsers_VehicleOwnerId",
                        column: x => x.VehicleOwnerId,
                        principalTable: "TblUsers",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TblReservations",
                columns: table => new
                {
                    ReservationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    VehicleId = table.Column<int>(type: "int", nullable: false),
                    SlotId = table.Column<int>(type: "int", nullable: false),
                    ReservationStartTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReservationEndTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblReservations", x => x.ReservationId);
                    table.ForeignKey(
                        name: "FK_TblReservations_TblParkingSlots_SlotId",
                        column: x => x.SlotId,
                        principalTable: "TblParkingSlots",
                        principalColumn: "SlotId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TblReservations_TblUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "TblUsers",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TblReservations_TblVehicles_VehicleId",
                        column: x => x.VehicleId,
                        principalTable: "TblVehicles",
                        principalColumn: "VehicleId",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TblReservations_SlotId",
                table: "TblReservations",
                column: "SlotId");

            migrationBuilder.CreateIndex(
                name: "IX_TblReservations_UserId",
                table: "TblReservations",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_TblReservations_VehicleId",
                table: "TblReservations",
                column: "VehicleId");

            migrationBuilder.CreateIndex(
                name: "IX_TblVehicles_VehicleOwnerId",
                table: "TblVehicles",
                column: "VehicleOwnerId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TblReservations");

            migrationBuilder.DropTable(
                name: "TblParkingSlots");

            migrationBuilder.DropTable(
                name: "TblVehicles");

            migrationBuilder.DropTable(
                name: "TblUsers");
        }
    }
}
