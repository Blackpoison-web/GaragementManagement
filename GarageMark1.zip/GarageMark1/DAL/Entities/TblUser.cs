﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GarageMark1.DAL.Entities
{
    public partial class TblUser
    {
        public TblUser()
        {
            TblReservations = new HashSet<TblReservation>();
            TblVehicles = new HashSet<TblVehicle>();
        }
        [Key]

        public int UserId { get; set; }
        public string Username { get; set; } = null!;
        public string Password { get; set; } = null!;
        public bool IsAdmin { get; set; }
        [EmailAddress]
        public string Email { get; set; } = null!;

        public virtual ICollection<TblReservation> TblReservations { get; set; }
        public virtual ICollection<TblVehicle> TblVehicles { get; set; }
    }
}
