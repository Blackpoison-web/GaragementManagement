import { useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import './App.css';

import { Table } from "react-bootstrap";
import { Button } from 'react-bootstrap';
import Card from 'react-bootstrap/Card'
import { useEffect } from "react";
import Modal from 'react-bootstrap/Modal';
import { Toast } from "bootstrap";
import { Fragment } from "react";
import { useNavigate } from "react-router-dom";

import DatePicker from "./Components/DatePicker"
import ButtonComponent1 from "./ButtonComponent1.js";
const Login = () => {
    const [data, setData] = useState([]);
    useEffect(() => {
        getData();
    }, [])
    const [reservation, setReservation] = useState([])

    const getReservation = () => {
        axios.get('https://localhost:7170/api/Reservation/api/Reservation/GetReservationByUserId/3').then((res) => {
            setReservation(res.data)
        })
            .catch((e) => {
                console.log(e)
            })

    }


    const navigate = useNavigate();
    const [vehicleName, setVehicleName] = useState("");
    const [plate, setPlate] = useState("");
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [show1, setShow1] = useState(false);
    const handleClose1 = () => setShow1(false);
    const handleShow1 = () => setShow1(true);
    const [show2, setShow2] = useState(false);
    const handleClose2 = () => setShow2(false);
    const handleShow2 = () => setShow2(true);
    const [slot, setSlot] = useState([]);
    const handleSlot = () => {

        getslot()
        handleShow1();
    }

    const [id, setid] = useState(63)
    const clear = () => {
        setVehicleName('');
        setPlate('');

    }
    const [fno, setfno] = useState()
    const [sno, setsno] = useState()
    const [sid, setsid] = useState()
    const getslot = () => {

        axios.get('https://localhost:7170/api/ParkingSlot/api/ParkingSlot/GetAvailableSlots').then((res) => {
            setSlot(res.data)

        }).catch((e) => {
            console.log(e)
        }
        )
    }
    const getData = () => {
        axios.get('https://localhost:7170/api/Vehicle/api/Vehicle/GetVehicleNamesByOwnerId/63').then((res) => {
            setData(res.data)
        })
            .catch((e) => {
                console.log(e)
            })

    }
    const handledata = (e) => {
        e.preventDefault();

        axios.get('https://localhost:7170/api/Vehicle/api/Vehicle/GetVehicleNamesByOwnerId/63')
            .then((result) => {
                setData(result.data)

            }).catch((error) => {
                console.log(error)
            })

    }

    const handleReg = (e) => {
        e.preventDefault();
        handleShow();
    }
    const toggle = (id) => {
        setsid(id)
    }
    const [isActive, setIsActive] = useState(false);
    const handleButtonClick = () => {
        setIsActive(!isActive);
    };
    const [vid, setvid] = useState()
    const handleRegister = (e) => {
        e.preventDefault();
        const d = {
            vehiclePlateNumber: plate,
            vehicleDescription: vehicleName,
            vehicleOwnerId: 3
        }
        axios.post('https://localhost:7170/api/Vehicle', d).then((res) => {
            if (res.status == 200) {
                toast.success("Registration Done");
                console.log("Doen")
                getData();
                clear();
                handleClose();

            }

        }
        ).catch((f) => {
            toast.error(f);
        })

    }
    useEffect(() => {
        console.log(sid)
    }, [sid]);
    useEffect(() => {
        console.log(vid + "kol")
    }, [vid]);
    const data1 = { userid: id, vehicleid: vid, slotid: sid };
    const handleDelte = (k, id) => {
        console.log(id)
        k.preventDefault();
        if (window.confirm("Are you sure to delete this record!") === true) {

            axios.delete(`https://localhost:7170/api/Vehicle?id=${id}`)
                .then((result) => {

                    if (result.status === 200) {
                        getData();
                        clear();
                        toast.success("Deleted Successfully");
                    }
                })
                .catch((error) => {
                    console.log(error);

                })

        }

    }
    const handlereserve = () => {
       getReservation()
        handleShow2();
    }
    return (
        <>  <ToastContainer /><div className="login " >
            <br></br>
            <h1></h1><div className=" justify-content-center d-flex"><button onClick={(e) => handleReg(e)} className="btn btn-danger">Register New Vehicle? Click Here</button></div>

            

            <br></br>
            <div className=" justify-content-center d-flex"><button onClick={(e) => handlereserve(e)} className="btn btn-danger">Show your Reservations</button></div> 
        <br></br>
            <div className=" justify-content-center d-flex flex-wrap">

                {

                    data.map((e, i) => {
                        return (
                            <>  <div key={i} className="d-inline-block">
                                <Card style={{ width: '18rem' }} border="light" text="dark">
                                    <Card.Img variant="top" src="" />
                                    <Card.Body  >
                                        <Card.Title align="center" text="dark">{e.vehicleDescription}</Card.Title>
                                        <Card.Text align="center" text="dark"><div className="lol">{e.vehiclePlateNumber}</div></Card.Text>
                                        <div className="justify-content-center d-flex rounded-pill" > <Button onClick={() => {
                                            setvid(e.vehicleId)
                                            setPlate(e.vehiclePlateNumber)
                                            setVehicleName(e.vehicleDescription)
                                            console.log(e.vehicleId + "logging e")
                                            handleSlot()
                                        }} variant="danger" >Book Your Slot</Button></div> <br></br>
                                        <div className="justify-content-center d-flex" onClick={(k) => handleDelte(k, e.vehicleId)}> <Button variant="danger">Delete</Button></div>
                                    </Card.Body>
                                </Card>
                                </div>

                               
                                            





                            </>
                        )
                    })


                }
                 <Modal show={show} onHide={handleClose}>

<Modal.Header >
    <Modal.Title>Register Your Vehicle</Modal.Title>
</Modal.Header>
<Modal.Body><b>Enter Your Vehicle Details!!!</b> <br />
    <form><label>Enter Vehicle Plate Number: </label> &nbsp;<input className='form-control' onChange={(e) => setPlate(e.target.value)} value={plate}></input> &nbsp;<br></br>
        <label>Enter Vehicle Name: </label> &nbsp;<input className='form-control' onChange={(e) => setVehicleName(e.target.value)} value={vehicleName}></input> <br></br>

        <br></br>
        &nbsp;


    </form>
</Modal.Body>

<Modal.Footer>
    <Button variant="secondary" onClick={handleClose}>
        Close
    </Button>
    <Button variant="primary" onClick={(e) => handleRegister(e)}>
        Register
    </Button>
</Modal.Footer>
</Modal>
//modal2
<Modal show={show1} onHide={handleClose1}>

<Modal.Header >
    <Modal.Title>Available Slots</Modal.Title>
</Modal.Header>
<Modal.Body><b>Select Your Slot!!!</b> <br />
    <Fragment>
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th>SLot Id</th>
                    <th>Floor No</th>
                    <th>Slot Number</th>


                </tr>
            </thead>
            <tbody>
                {

                    slot.map((e, i) => {
                        return (
                            <>
                                <tr key={i}>
                                    <td>{e.slotId}</td>
                                    <td>{e.floorNumber}</td>
                                    <td>{e.slotNumber}</td>
                                    <td>   </td>
                                    <ButtonComponent1 fno={e.floorNumber} vname={vehicleName} vplate={plate} sno={e.slotNumber} sid={e.slotId} uid={id} vid={vid} />
                                </tr>


                            </>
                        )
                    })
                }
                <br></br>

            </tbody>

        </Table>

    </Fragment>
</Modal.Body>

<Modal.Footer>
    <Button variant="secondary" onClick={handleClose1}>
        Close
    </Button>

</Modal.Footer>
</Modal>



//modal 3

<Modal show={show2} onHide={handleClose2}>

<Modal.Header >
    <Modal.Title>Your Reservations</Modal.Title>
</Modal.Header>
<Modal.Body><b>These are Your Reservations!!!</b> <br />
    <Fragment>
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th>SLot Id</th>
                    <th>In Time</th>
                    <th>Out Time</th>


                </tr>
            </thead>
            <tbody>
                {

                    reservation.map((e, i) => {
                        return (
                            <>
                                <tr key={i}>
                                    <td>{e.slotId}</td>
                                    <td>{e.reservationStartTime}</td>
                                    <td>{e.reservationEndTime}</td>
                                    
                                </tr>


                            </>
                        )
                    })
                }
                <br></br>

            </tbody>

        </Table>

    </Fragment>
</Modal.Body>

<Modal.Footer>
    <Button variant="secondary" onClick={handleClose2}>
        Close
    </Button>

</Modal.Footer>
</Modal>


            </div>

        </div>
        </>
    )
}
export default Login;