﻿using System;
using System.Collections.Generic;

namespace GarageMark1.DAL.Entities
{
    public partial class TblParkingSlot
    {
        public TblParkingSlot()
        {
            TblReservations = new HashSet<TblReservation>();
        }

        [System.ComponentModel.DataAnnotations.Key]
        public int SlotId { get; set; }
        public int FloorNumber { get; set; }
        public string SlotNumber { get; set; } = null!;
        public bool IsReserved { get; set; }

        public virtual ICollection<TblReservation> TblReservations { get; set; }
    }
}
