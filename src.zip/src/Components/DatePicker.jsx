import DateTimePicker from "react-datetime-picker";
import { useState } from "react";
import { useLocation } from "react-router-dom";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import { Table } from "react-bootstrap";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import Login from "../Login";
import { useNavigation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import photo from './Assets/garage1.avif'
import './App.css';
const DatePicker = () => {
    const navigate = new useNavigate()
    const location = useLocation()
    const [uid, setuid] = useState(location.state.userid)
    const [vid, setvid] = useState(location.state.vehicleid)
    const [sid, setvsid] = useState(location.state.slotid)

    const [invalue, setInValue] = useState()
    const [outvalue, setOutValue] = useState()

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const handleDone = (e) => {
        e.preventDefault();
    
        if(outvalue>invalue){
        handleShow();
        console.log(typeof invalue)
        }
       else{
        toast.error("Out Time is Less Than In Time!!! Please Select Correct Time !!!")
       }
    
   
    }
    const test = (e) => {
        e.preventDefault();
        setuid(location.state.userid)
        console.log(uid)
        console.log(invalue)
    }

    const handleConfirm = (e) => {

        const d = {
            userId: uid,
            vehicleId: vid,
            slotId: sid,
            reservationStartTime: invalue,
            reservationEndTime: outvalue
        }
      
        axios.post('https://localhost:7170/api/Reservation', d).then((res) => {
            if (res.status == 200) {
                toast.success("Reservation Done");
                console.log("Doen")

                axios.post(`https://localhost:7170/api/Reservation/api/Reservation/UpdateSlot/${sid}`)
                handleClose();


            
            }

        }
        ).catch((f) => {
            toast.error(f);
        })
        navigate("/Home",{state: location.state.userid})
  

    }
    const back={
        backgroundImage: `url(${photo})`
    }
    return (
        <>
         

            <div className=" login3 justify-content-center d-flex  bg-dark" style={back}>

                <ToastContainer />

                {/* <div className="date justify-content-center d-flex shadow p-3 mb-5 zoom1  rounded">

                    <form >

                        <br></br>

                        <br></br>
                        <div class="form-group">
                            <label className="text-black" for="exampleInputEmail1"><b>Select Start Time</b></label> <br></br>
                            <input type="datetime-local" onChange={(e) => setInValue(e.target.value)} value={invalue} />

                        </div>
                        <div class="form-group">
                            <label className="text-black" for="exampleInputPassword1"><b>Select End Time</b></label> <br></br>
                            <input type="datetime-local" onChange={(e) => setOutValue(e.target.value)} value={outvalue} />
                        </div> <div className="justify-content-center d-flex">
                            <br></br>
                            <br></br>

                            <button type="" onClick={handleCon} class="btn btn-danger">Submit</button>
                        </div>
                    </form>
                </div> */}
                <div class="container mt-4 ">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card ">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0">Select Reservation Time</h4>
                    </div>
                    <div class="card-body lol1 ">
                        <div class="form-group ">
                       <div className="justify-content-center d-flex  "> <label className="text-black" for="exampleInputEmail1"><b>Select Start Time</b></label> <br></br> </div>
                           <div className="justify-content-center d-flex"> <input type="datetime-local" onChange={(e) => setInValue(e.target.value)} value={invalue} required /> </div>
                           
                        </div>
                        <div class="form-group ">
                       <div className="justify-content-center d-flex"> <label className="text-black" for="exampleInputPassword1"><b>Select End Time</b></label></div> 
                       <div className="justify-content-center d-flex"> <input type="datetime-local" onChange={(e) => setOutValue(e.target.value)} value={outvalue} required /></div>
                        </div>
                        
                        <button class="btn btn-success btn-block" onClick={handleDone}>Done</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
                <Modal show={show} onHide={handleClose}>

                    <Modal.Header >
                        <Modal.Title>Confirm Your Details</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>Vehicle Name</th>
                                    <th>Vehicle Plate number</th>
                                    <th>Slot No</th>
                                    <th>Floor No</th>
                                    <th>In time</th>
                                    <th>Out Time</th>


                                </tr>
                            </thead>
                            <tbody>


                                <tr >
                                    <td>{location.state.vname}</td>
                                    <td>{location.state.vplate}</td>

                                    <td>{location.state.sno}</td>
                                    <td>{location.state.fno} </td>
                                    <td>{invalue}</td>
                                    <td>{outvalue}</td>


                                </tr>



                                <br></br>

                            </tbody>

                        </Table>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="danger" onClick={handleClose}>
                            Close
                        </Button>
                        <Button variant="success" onClick={handleConfirm} >
                            Confirm
                        </Button>
                    </Modal.Footer>
                </Modal>










            </div>
        </>
    )
}
export default DatePicker;