﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GarageMark1.DAL.Entities
{
    public partial class TblReservation
    {
        [Key]
        public int ReservationId { get; set; }
        public int UserId { get; set; }
        public int VehicleId { get; set; }
        public int SlotId { get; set; }
        public DateTime ReservationStartTime { get; set; }
        public DateTime ReservationEndTime { get; set; }

        public virtual TblParkingSlot Slot { get; set; } = null!;
        public virtual TblUser User { get; set; } = null!;
        public virtual TblVehicle Vehicle { get; set; } = null!;
    }
}
