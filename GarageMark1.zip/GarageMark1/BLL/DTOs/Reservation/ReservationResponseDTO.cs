﻿namespace GarageMark1.BLL.DTOs.Reservation
{
    public class ReservationResponseDTO
    {
        public int ReservationId { get; set; }
        public int UserId { get; set; }
        public int VehicleId { get; set; }
        public int SlotId { get; set; }
        public DateTime ReservationStartTime { get; set; }
        public DateTime ReservationEndTime { get; set; }
        public string UserUsername { get; set; }
    }
}
