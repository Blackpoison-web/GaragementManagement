const Footer=()=>{
    return(
        <>
     
<footer className="page-footer font-small  bg-dark  pt-1">

  
  <div className="container-fluid text-center text-md-left">

   
  
 

  </div>


  <div className="footer-copyright text-white text-center py-3">© 2024 Copyright : Official.prateekbabuni@gmail.com
  </div>


</footer>

        </>
    );
}
export default Footer;