﻿using GarageMark1.DAL.DBContext;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories.Interfaces;

namespace GarageMark1.DAL.Repositories.Implementations
{
    public class UserRepository : RepositoryBase<TblUser>, IUserRepository
    {
        public UserRepository(GarageContext dbContext) : base(dbContext)
        {
        }
    }

}
