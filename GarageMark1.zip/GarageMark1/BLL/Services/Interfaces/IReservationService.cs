﻿using GarageMark1.BLL.DTOs.Reservation;

namespace GarageMark1.BLL.Services.Interfaces
{
    public interface IReservationService: IBaseService<ReservationRequestDTO, ReservationResponseDTO>
    {
    }
}