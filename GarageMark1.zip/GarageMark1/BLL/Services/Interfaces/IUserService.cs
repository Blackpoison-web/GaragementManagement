﻿using AutoMapper;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories;
using GarageMark1.DAL.Repositories.Interfaces;

namespace GarageMark1.BLL.Services.Interfaces
{
    public interface IUserService : IBaseService<UserRequestDTO, UserResponseDTO>
    {
    }
    
}
