﻿namespace GarageMark1.BLL.DTOs.ParkingSlot
{
    public class ParkingSlotRequestDTO
    {
      
        public int FloorNumber { get; set; }
        public string SlotNumber { get; set; } = null!;
        public bool IsReserved { get; set; }
    }
}
