﻿using AutoMapper;
using GarageMark1.BLL.DTOs.Vehicle;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories;
using GarageMark1.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GarageMark1.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly IVehicleService VehicleService;
        private readonly IMapper mapper;
        private readonly IRepositoryWrapper repository;
        public VehicleController(IVehicleService productService, IMapper mapper, IRepositoryWrapper repositoryg)
        {
            this.VehicleService = productService;
            this.mapper = mapper;
            this.repository = repositoryg;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var products = await this.repository.VehicleRepository.GetAllAsync("VehicleOwner");

            var result = mapper.Map<IEnumerable<VehicleResponseDTO>>(products);


            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Post(VehicleRequestDTO v)
        {
            var result = await this.VehicleService.Add(v);
            return Ok(result);
        }
        [HttpGet("id")]
        public async Task<IActionResult> GetbyId(int id)
        {
            var result = await this.VehicleService.GetById(id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await this.VehicleService.Delete(id);
            if (data == true)
            {
                return Ok("the data is deleted");
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet("api/[controller]/getname/{id}")]
        public async Task<IActionResult> GetName(int id)
        {
            var f = await this.VehicleService.GetName1(id);
            if (f == null)
            {
                return Ok("Data Not Found");
            }
            return Ok(f);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> EditVehicle(int id,VehicleRequestDTO v)
        {
            
            await this.VehicleService.Update(id,v);
            return Ok(v);
        }
        [HttpGet("api/[controller]/getvehiclename/{id}")]
        public async Task<IActionResult> GetVehicleName(int id)
        {
            var f = await this.VehicleService.GetVehicleNames(id);
            if (f == null)
            {
                return Ok("Data Not Found");
            }
            return Ok(f);
        }
    }
}
