﻿using GarageMark1.BLL.DTOs.ParkingSlot;

namespace GarageMark1.BLL.Services.Interfaces
{
    public interface IParkingSlotService:IBaseService<ParkingSlotRequestDTO,ParkingSlotResponseDTO>
    {
    }
}
