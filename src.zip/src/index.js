import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Users from './Components/Users';
import Test from './Components/Test';
import reportWebVitals from './reportWebVitals';
import Landing from './Components/Landing';
import Login from './Login';
import { Route, RouterProvider, createBrowserRouter, createRoutesFromElements } from 'react-router-dom'
import Layout from './Layout.jsx'
import Admin from './Components/Admin'
import About from './Components/About';

import Reservation from './Components/Reservation';
import ParkingSlot from './Components/ParkingSlot';
import DatePicker from './Components/DatePicker';
const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<Layout />}>
      <Route path='' element={<Landing/>}/>
      <Route path='Login' element={<Login/>}/>
      <Route path='Date' element={<DatePicker/>}/>
      <Route path='Home' element={<Test/>}/>
      <Route path='Admin' element={<Admin/>}/>
      <Route path='Users' element={<Users/>}/>
      <Route path='Reservation' element={<Reservation/>}/>
      <Route path='Slots' element={<ParkingSlot/>}/>
      <Route path='About' element={<About/>}/>
    </Route>
  )
)

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
   <RouterProvider router={router} />

  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
