import './App.css';
import Head from "./Components/Head";
import Footer from "./Components/Footer";
import {Outlet} from 'react-router-dom'
const Layout=()=>{
    return(
        <>
        <Head/>
      
      <Outlet/>
     
    
        
        <Footer/>
        </>
    )
}
export default Layout;