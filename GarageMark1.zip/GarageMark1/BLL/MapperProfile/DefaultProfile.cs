﻿using AutoMapper;
using GarageMark1.BLL.DTOs.ParkingSlot;
using GarageMark1.BLL.DTOs.Reservation;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.DTOs.Vehicle;
using GarageMark1.DAL.Entities;

namespace GarageMark1.BLL.MapperProfile
{
    public class DefaultProfile: Profile
    {
        public DefaultProfile()
        {
            CreateMap<VehicleRequestDTO, TblVehicle>();

            CreateMap<TblVehicle, VehicleResponseDTO>();

            CreateMap<UserRequestDTO,TblUser>();
            CreateMap<TblUser, UserResponseDTO>();

            CreateMap<ParkingSlotRequestDTO, TblParkingSlot>();
            CreateMap<TblParkingSlot, ParkingSlotResponseDTO>();

            CreateMap<ReservationRequestDTO, TblReservation>();
            CreateMap<TblReservation, ReservationResponseDTO>();
        }
        
    }
}
