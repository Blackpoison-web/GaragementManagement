﻿namespace GarageMark1.BLL.DTOs.Vehicle
{
    public class VehicleRequestDTO
    {
        public string VehiclePlateNumber { get; set; } = null!;
        public string? VehicleDescription { get; set; }
        public int VehicleOwnerId { get; set; }
    }
}
