
import b from './b.webp'
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import { useState } from 'react'
import { Button } from 'react-bootstrap';
import axios from "axios";
import photo from './Assets/Landing.jpg'
import Modal from 'react-bootstrap/Modal';
import Card from 'react-bootstrap/Card'
import "react-toastify/dist/ReactToastify.css";
import { Toast } from "bootstrap";

const Landing = () => {
    const navigate = new useNavigate()
    const [userName, setuserName] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [isAdmin, setIsAdmin] = useState(false)
    const [show, setShow] = useState(false);
    const [show1, setShow1] = useState(false);
    const handleClose1 = () => setShow1(false);
    const handleShow1 = () => setShow1(true);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const EditHandleActive = (e) => {
        if (e.target.checked == true) {
            setIsAdmin(true);
        }
        else {
            setIsAdmin(false);
        }
    }
    const clear = () => {
        setuserName('');
        setEmail('');
        setPassword("")
        setIsAdmin(false)

    }
    const handleRegister = (e) => {
        e.preventDefault();
        const data = {

            username: userName,
            password: password,
            isAdmin: isAdmin,
            email: email
        }
        axios.post('https://localhost:7170/api/User', data).then((res) => {
            if (res.status == 200) {
                toast.success("Registration Done");
               clear()
                handleClose();

            }


        }
        ).catch((f) => {
            toast.error("Invalid Input !!!");
            handleClose();
        })
    }
    const handleReg = (e) => {
        e.preventDefault();
        handleShow();
    }
    const handleLog = (e) => {
        e.preventDefault();
        handleShow1();
    }
    const handlelogin = (e, email, password) => {
        e.preventDefault()
        const data = {
            email: email,
            password: password
        }
        axios.post('https://localhost:7170/api/User/api/User/Login', data).then((res) => {
            console.log(res.data)
            if (res.status == 200) {
                if (res.data != 71) {
                    const d = res.data
                    localStorage.setItem('id', res.data);
                  
                    navigate("/Home", { state: res.data })
                    window.location.reload();
                }
                else {
                    localStorage.setItem('id', res.data);
                  
                    navigate("/admin")
                    window.location.reload();
                }
            }
            else {
                toast.error("Enter correct email id or password")
                handleClose1()
            }
        }).catch((e) => {
            toast.error("Enter Correct Email or Password!!!")
        })

    }
    const back={
        backgroundImage: `url(${photo})`
    }
 
    return (
        <>
            <div className="App"  style={back}>
                <header className="landing">
                    <ToastContainer />
                    <br />
                    <h1 className='demo'>Welcome to your Parking Slot Booking Place</h1><br />
             
                    <button className="btn btn-success btn-lg" onClick={(e) => handleReg(e)} >New User? Register Yourself</button>
                    <br />
                    <div className="hero">
                        <div className="card mb-3 bg-white text-black border-0">
                            {/* <img src={photo}></img> */}
                        </div>
                    </div>
                    <button className="btn btn-md btn-danger" onClick={(e) => handleLog(e)}>Login</button>
           
                  
                    <Modal show={show} onHide={handleClose}>

                        <Modal.Header >
                            <Modal.Title>Please Register Yourself</Modal.Title>
                        </Modal.Header>
                        <Modal.Body><b>Enter your Details!!!</b> <br />
                            <form><label>Enter Username: </label> &nbsp;<input className='form-control' onChange={(e) => setuserName(e.target.value)} value={userName}></input> &nbsp;<br></br>
                                <label>Email: </label> &nbsp;<input className='form-control' onChange={(e) => setEmail(e.target.value)} value={email}></input> <br></br>
                                <label>Enter password: </label> &nbsp;<input type='password' className='form-control' onChange={(e) => setPassword(e.target.value)} value={password}></input>
                                <br></br>
                                &nbsp;


                            </form>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="danger" onClick={handleClose}>
                                Close
                            </Button>
                            <Button variant="success" onClick={(e) => handleRegister(e)}>
                                Register
                            </Button>
                        </Modal.Footer>
                    </Modal>
                    <Modal show={show1} onHide={handleClose1}>

                        <Modal.Header >
                            <Modal.Title>Login Yourself</Modal.Title>
                        </Modal.Header>
                        <Modal.Body><b>Enter your Login Details!!!</b> <br></br>
                            <form><label>Enter Email: </label> &nbsp;<input className='form-control' onChange={(e) => setEmail(e.target.value)} value={email}></input> &nbsp;<br></br>

                                <label>Enter password: </label> &nbsp;<input type='password' className='form-control' onChange={(e) => setPassword(e.target.value)} value={password}></input>
                                &nbsp;


                            </form>
                        </Modal.Body>

                        <Modal.Footer>
                            <Button variant="danger" onClick={handleClose1}>
                                Close
                            </Button>
                            <Button variant="success" onClick={(e) => handlelogin(e, email, password)}  >
                                Login
                            </Button>
                        </Modal.Footer>
                    </Modal>
                </header>
            </div>
        </>
    );
}

export default Landing;