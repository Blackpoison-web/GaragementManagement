﻿using GarageMark1.DAL.DBContext;
using GarageMark1.DAL.Repositories.Interfaces;

namespace GarageMark1.DAL.Repositories.Implementations
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private readonly GarageContext dbContext;

        public IVehicleRepository VehicleRepository { get; set; }
        public IUserRepository UserRepository { get; set; }
        public IReservationRepository ReservationRepository { get; set; }
        public IParkingSlotRepository ParkingSlotRepository { get; set; }

        public RepositoryWrapper(GarageContext dbContext)
        {
            this.dbContext = dbContext;

            VehicleRepository = new VehicleRepository(dbContext);
            UserRepository = new UserRepository(dbContext);
            ReservationRepository= new ReservationRepository(dbContext);
            ParkingSlotRepository=new ParkingSlotRepository(dbContext);

        }

        public async Task<int> SaveAsync()
        {
            return await this.dbContext.SaveChangesAsync();
        }

    }
}
