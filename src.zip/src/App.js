import logo from './logo.svg';
import './App.css';

import Head from './Components/Head';
import Landing from './Components/Landing';
import Footer from './Components/Footer';
function App() {
  return (
    <>
    <Head/>
    
    {/* <div className="App">
      <header className="App-header">
      <Landing/>
      </header>
    </div>
  
    <Footer/> */}
    </>
  );
 
}

export default App;
