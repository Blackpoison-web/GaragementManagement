import Table from 'react-bootstrap/Table';
import { useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { useEffect } from 'react';
const ParkingSlot = () => {
    const [data, setData] = useState([])
    const [floorNumber, setFloorNumber] = useState()
    const [slotNumber, setSlotNumber] = useState()
    const getData = () => {
        if(localStorage.getItem("id")==71){
        axios.get('https://localhost:7170/api/ParkingSlot').then((res) => {
            setData(res.data)
        }).catch((e) => {
            console.log(e)
        })
    }
    }
    useEffect(() => {
        getData();
    }, [data])

    const handletoggle = (id, k) => {
        k.preventDefault()
    

        axios.post(`https://localhost:7170/api/Reservation/api/Reservation/UpdateSlot/${id}`).then((res) => {
            console.log(res.status)
            toast.success("Updated Successfully")
            getData()
        }).catch((e) => {
            console.log(e)
        })
    }
    const handleSubmit = (e) => {
        e.preventDefault()
        const data = {

            floorNumber: floorNumber,
            slotNumber: slotNumber,
            isReserved: false

        }
        axios.post('https://localhost:7170/api/ParkingSlot', data).then((res) => {
            toast.success("Successfully Added")
        }).catch((e) => {
            toast.error(e)
        })

    }
    const handleDelete = (id, e) => {
        e.preventDefault()
        axios.delete(`https://localhost:7170/api/ParkingSlot?id=${id}`).then((res) => {
            toast.success("Deleted Successfully")
            getData()
        }).catch((e) => {
            toast.error(e)
        })
    }
    return (
        <>
            <ToastContainer />
            
            <div className="login3">
                <form >
                    <div class="form-group">
                        <label for="floorNumber" className='text-white'>Floor Number</label>
                        <input type="number" class="form-control" placeholder='Enter FloorNumber' id="floorNumber" onChange={(e) => setFloorNumber(e.target.value)} name="floorNumber" value={floorNumber} required />
                    </div>
                    <div class="form-group">
                        <label for="slotNumber" className='text-white'>Slot Number</label>
                        <input type="text" class="form-control" id="slotNumber" name="slotNumber" onChange={(e) => setSlotNumber(e.target.value)} value={slotNumber} placeholder="Enter slot number" required />
                    </div>

                    <button type="submit" class="btn btn-primary" onClick={(e) => handleSubmit(e)}>Submit</button>

                </form>
                <br></br>
                <Table striped>
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Slot Id</th>
                            <th>Floor Number</th>
                            <th>Slot Number</th>
                            <th>Is Reserved</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {

                            data.map((e, i) => {
                                return (
                                    <>
                                        <tr key={i}>
                                            <td>{i + 1}</td>
                                            <td>{e.slotId}</td>
                                            <td>{e.floorNumber}</td>
                                            <td>{e.slotNumber}</td>
                                            <td>{e.isReserved.toString()}</td>
                                            <td><button onClick={(k) => { handletoggle(e.slotId, k) }} className="btn btn-sm btn-danger">Change Status</button> <button onClick={(k) => { handleDelete(e.slotId, k) }} className="btn btn-sm btn-danger">Delete</button> </td>


                                        </tr>


                                    </>
                                )
                            })
                        }


                    </tbody>
                </Table>
            </div>
        </>
    )
}
export default ParkingSlot;
