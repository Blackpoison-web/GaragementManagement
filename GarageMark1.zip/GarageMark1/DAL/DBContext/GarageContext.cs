﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using GarageMark1.DAL.Entities;

namespace GarageMark1.DAL.DBContext
{
    public partial class GarageContext : DbContext
    {
        public GarageContext()
        {
        }

        public GarageContext(DbContextOptions<GarageContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblParkingSlot> TblParkingSlots { get; set; } = null!;
        public virtual DbSet<TblReservation> TblReservations { get; set; } = null!;
        public virtual DbSet<TblUser> TblUsers { get; set; } = null!;
        public virtual DbSet<TblVehicle> TblVehicles { get; set; } = null!;

      
    }
}
