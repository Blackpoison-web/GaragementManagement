﻿using GarageMark1.DAL.DBContext;
using GarageMark1.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;


namespace GarageMark1.DAL.Repositories.Interfaces
{
    public interface IBaseRepository<T> where T : class
    {
        Task<T> CreateAsync(T entity);

        Task<T> UpdateAsync(int id,T entity);

        Task<bool> DeleteAsync(T entity);

        Task<IEnumerable<T>> GetAllAsync(params string[] navsToInclude);

        Task<T?> GetById(int id);

        Task<IEnumerable<T>> GetByCondition(Expression<Func<T, bool>> condition);
    }













}
