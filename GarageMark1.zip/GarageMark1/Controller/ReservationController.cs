﻿using AutoMapper;
using GarageMark1.BLL.DTOs.Reservation;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GarageMark1.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private readonly IReservationService ReservationService;
        private readonly IMapper mapper;
        private readonly IRepositoryWrapper repository;
        public ReservationController(IReservationService productService, IMapper mapper, IRepositoryWrapper repositoryg)
        {
            this.ReservationService = productService;
            this.mapper = mapper;
            this.repository = repositoryg;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await this.repository.ReservationRepository.GetAllAsync("User");

            var result = mapper.Map<IEnumerable<ReservationResponseDTO>>(data);


            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Post(ReservationRequestDTO v)
        {
            var result = await this.ReservationService.Add(v);
            return Ok(result);
        }
        [HttpGet("id")]
        public async Task<IActionResult> GetbyId(int id)
        {
            var result = await this.ReservationService.GetById(id);
            return Ok(result);
        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await this.ReservationService.Delete(id);
            if (data == true)
            {
                return Ok("the data is deleted");
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> EditReservation(int id, ReservationRequestDTO v)
        {

            await this.ReservationService.Update(id, v);
            return Ok(v);
        }
    }
}
