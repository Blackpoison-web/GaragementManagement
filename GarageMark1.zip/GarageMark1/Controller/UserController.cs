﻿using AutoMapper;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.DTOs.Vehicle;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.Repositories;
using GarageMark1.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GarageMark1.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService UserService;
        private readonly IMapper mapper;
        private readonly IRepositoryWrapper repository;
        public UserController(IUserService productService, IMapper mapper, IRepositoryWrapper repositoryg)
        {
            this.UserService = productService;
            this.mapper = mapper;
            this.repository = repositoryg;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var products = await this.repository.UserRepository.GetAllAsync();

            var result = mapper.Map<IEnumerable<UserResponseDTO>>(products);


            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Post(UserRequestDTO v)
        {
            var result = await this.UserService.Add(v);
            return Ok(result);
        }
        [HttpGet("id")]
        public async Task<IActionResult> GetbyId(int id)
        {
            var result = await this.UserService.GetById(id);
            return Ok(result);
        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await this.UserService.Delete(id);
            if (data == true)
            {
                return Ok("the data is deleted");
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> EditUser(int id, UserRequestDTO v)
        {

            await this.UserService.Update(id, v);
            return Ok(v);
        }
    }
}
