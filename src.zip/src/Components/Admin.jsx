import Card from 'react-bootstrap/Card';
import {Button} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import photo from './Assets/garage1.avif'
const Admin = () => {
const navigate=new useNavigate()
const user=()=>{
    navigate("/Users")
}
const slots=()=>{
    navigate("/Slots")
}
const reservation=()=>{
    navigate("/Reservation")
}
const back={
    backgroundImage: `url(${photo})`,
   
}
    return (
        <> <div style={back}>
            <br></br>  <br></br>  <br></br>
        <span className="psuedo justify-content-center d-flex"><h1>Admin DashBoard</h1></span>
        <br></br>
            <div className="login2 d-flex justify-content-around flex-wrap" >
               
                <div className="d-inline-block zoom">
                <Card style={{ width: '18rem' }}>
                    {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                    <Card.Body>
                        <Card.Title align="center">Users</Card.Title>
                        <Card.Text>
                           
                        </Card.Text>
                       <div className='justify-content-center d-flex'> <Button variant="danger" onClick={user}>Click Here</Button></div>
                    </Card.Body>
                </Card>
                </div>
                <div className="d-inline-block zoom">
                <Card style={{ width: '18rem' }}>
                 {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                    <Card.Body>
                     <Card.Title align="center">Parking Slots</Card.Title>
                        <Card.Text>
                         
                        </Card.Text>
                        <div className='justify-content-center d-flex'> <Button variant="danger" onClick={slots} >Click Here</Button></div>
                    </Card.Body>
                </Card>
                </div>
                <div className="d-inline-block zoom">
                <Card style={{ width: '18rem' }}>
                    {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
                    <Card.Body>
                        <Card.Title align="center">Reservations</Card.Title>
                        <Card.Text>
                           
                        </Card.Text>
                        <div className='justify-content-center d-flex'> <Button variant="danger" onClick={reservation}>Click Here</Button></div>
                    </Card.Body>
                </Card>
                </div>
            </div>
            </div>
        </>
    )
}
export default Admin;