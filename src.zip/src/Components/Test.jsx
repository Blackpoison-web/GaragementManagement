import { useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import './App.css';
import b from './b.webp'
import photo from './Assets/garage1.avif'
import Carousel from 'react-bootstrap/Carousel';
import { Table } from "react-bootstrap";
import { Button } from 'react-bootstrap';
import Card from 'react-bootstrap/Card'
import { useEffect } from "react";
import Modal from 'react-bootstrap/Modal';
import { Toast } from "bootstrap";
import { Fragment } from "react";
import { useNavigate } from "react-router-dom";

import { useLocation } from "react-router-dom";
import ButtonComponent1 from "../ButtonComponent1";
const Test = () => {
    const location = useLocation()
    const navigate = useNavigate()

    //Get Vehicles Registered by Id

    const [data, setData] = useState([]);
    const getData = async () => {
        await axios.get(`https://localhost:7170/api/Vehicle/api/Vehicle/GetVehicleNamesByOwnerId/${localStorage.getItem('id')}`).then((res) => {
            setData(res.data)
        })
            .catch((e) => {
                console.log(e)
            })

    }
    useEffect(() => {
        getData();
    }, [])

    // Handle Modal For Registering Vehicle

    const [showRegisterVehicleModal, setShowRegisterVehicleModal] = useState(false);
    const handleRegisterVehicleModalClose = () => setShowRegisterVehicleModal(false);
    const handleRegisterVehicleModalShow = () => setShowRegisterVehicleModal(true);
    const handleRegisterModalClick = (e) => {
        e.preventDefault();
        handleRegisterVehicleModalShow();
    }


    const clearRegisterVehicleForm = () => {
        setVehicleName('');
        setPlate('');

    }
    const handleRegister = async (e) => {
        e.preventDefault();
        const d = {
            vehiclePlateNumber: plate,
            vehicleDescription: vehicleName,
            vehicleOwnerId: location.state
        }
        await axios.post('https://localhost:7170/api/Vehicle', d).then((res) => {
            if (res.status == 200) {
                toast.success("Registration Done");
                console.log("Doen")
                getData();
                clearRegisterVehicleForm();
                handleRegisterVehicleModalClose();

            }

        }
        ).catch((f) => {
            toast.error("Please Enter Valid Vehicle Plate Number And Vehicle Name !!!");
            handleRegisterVehicleModalClose()
        })

    }


    // Handle Modal for Reservations

    const [reservation, setReservation] = useState([])
    const getReservation = async () => {
        await axios.get(`https://localhost:7170/api/Reservation/api/Reservation/GetReservationByUserId/${localStorage.getItem('id')}`).then((res) => {
            setReservation(res.data)
        })
            .catch((e) => {
                console.log(e)
            })

    }
    const handleReservations = () => {
        getReservation()
        console.log(location.state)
        handleShowReservations();

    }



    const [vehicleName, setVehicleName] = useState();
    const [plate, setPlate] = useState("");

    // Handle Modal For Showing Available Parking Slots

    const [slot, setSlot] = useState([]);

    
    const getslot = async () => {

        await axios.get('https://localhost:7170/api/ParkingSlot/api/ParkingSlot/GetAvailableSlots').then((res) => {
            setSlot(res.data)

            if (res.data === undefined) {
                toast.error("No Slots Available!!!")
            }
        }).catch((e) => {
            console.log(e)
        }
        )
    }
    const handleSlot = () => {

        getslot()
        handleShowAvailabelSlotModal();
    }

    const [showAvailabelSlotModal, setShowAvailabelSlotModal] = useState(false);
    const handleCloseAvailabelSlotModal = () => setShowAvailabelSlotModal(false);
    const handleShowAvailabelSlotModal = () => setShowAvailabelSlotModal(true);
    const [showReservations, setShowReservations] = useState(false);
    const handleCloseReservations = () => setShowReservations(false);
    const handleShowReservations = () => setShowReservations(true);




    const [vid, setvid] = useState()

    // useEffect(() => {
    //     console.log(sid)
    // }, [sid]);
    // useEffect(() => {
    //     console.log(vid + "kol")
    // }, [vid]);

    // Delete Registered Vehicle

    const handleDelte = async (k, id) => {
        console.log(id)
        k.preventDefault();
        if (window.confirm("Are you sure to delete this Vehicle!") === true) {

            await axios.delete(`https://localhost:7170/api/Vehicle?id=${id}`)
                .then((result) => {

                    if (result.status === 200) {
                        getData();

                        toast.success("Deleted Successfully");
                    }
                })
                .catch((error) => {
                    toast.error("Remove After Reservation End");

                })

        }

    }

    const back = {
        backgroundImage: `url(${photo})`,

    }
    return (
        <>  <ToastContainer /><div className="login " style={back}>
            <br></br>
            <h1></h1><div className=" justify-content-center d-flex"><button onClick={(e) => handleRegisterModalClick(e)} className="btn btn-success">Register New Vehicle? Click Here</button></div>



            <br></br>


            <div>
                <div className=" justify-content-center d-flex text-white"><h2>These Are Your Registered Vehicles</h2></div>
                <br></br>

                <Carousel>
                    {data.map(e => (

                        <Carousel.Item key={e.id} fade={true}>
                            <div className="justify-content-center d-flex">
                                <Card style={{ width: '18rem', backgroundColor: '#bac8d6' }} border="light" text="dark">
                                    <Card.Img variant="top" src="" />
                                    <Card.Header style={{ color: 'black', fontFamily: 'Roboto', fontSize: '1.25rem' }}>
                                        <b className="justify-content-center d-flex">VEHICLE DETAILS</b>
                                    </Card.Header>
                                    <Card.Body>
                                        <Card.Title style={{ color: 'black', fontFamily: 'Roboto', fontSize: '1.7rem' }} align="center" text="dark">
                                            {e.vehicleDescription}
                                        </Card.Title>
                                        <Card.Text align="center" text="dark">
                                            <div className="lol" style={{ backgroundColor: 'white' }}>{e.vehiclePlateNumber}</div>
                                        </Card.Text>
                                        <div className="justify-content-center d-flex rounded-pill">
                                            <Button
                                                onClick={() => {
                                                    setvid(e.vehicleId);
                                                    setPlate(e.vehiclePlateNumber);
                                                    setVehicleName(e.vehicleDescription);

                                                    handleSlot();
                                                }}
                                                variant="success"
                                            >
                                                <b>Book Your Parking Slot</b>
                                            </Button>
                                        </div>
                                        <br />
                                        <div className="justify-content-center d-flex" onClick={(k) => handleDelte(k, e.vehicleId)}>
                                            <Button variant="danger">
                                                <b>Delete</b>
                                            </Button>
                                        </div>
                                    </Card.Body>
                                    <br />
                                </Card>
                            </div>
                        </Carousel.Item>
                    ))}
                </Carousel>
            </div>

            <br></br>
            <br></br>
            <div className=" justify-content-center d-flex"><button onClick={(e) => handleReservations(e)} className="btn btn-success">Show your Reservations</button></div> <br></br>
            <Modal show={showRegisterVehicleModal} onHide={handleRegisterVehicleModalClose}>

                <Modal.Header >
                    <Modal.Title>Register Your Vehicle</Modal.Title>
                </Modal.Header>
                <Modal.Body><b>Enter Your Vehicle Details!!!</b> <br />
                    <form><label>Enter Vehicle Plate Number: </label> &nbsp;<input className='form-control' onChange={(e) => setPlate(e.target.value)} value={plate} required></input> &nbsp;<br></br>
                        <label>Enter Vehicle Name: </label> &nbsp;<input type="text" className='form-control' onChange={(e) => setVehicleName(e.target.value)} value={vehicleName} required></input> <br></br>

                        <br></br>
                        &nbsp;


                    </form>
                </Modal.Body>

                <Modal.Footer>
                    <Button variant="secondary" onClick={handleRegisterVehicleModalClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={(e) => handleRegister(e)}>
                        Register
                    </Button>
                </Modal.Footer>
            </Modal>

            <Modal show={showAvailabelSlotModal} onHide={handleCloseAvailabelSlotModal}>

                <Modal.Header >
                    <Modal.Title>Available Slots</Modal.Title>
                </Modal.Header>
                <Modal.Body><b>Select Your Slot!!!</b> <br />
                    <Fragment>
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Slot Id</th>
                                    <th>Floor No</th>
                                    <th>Slot Number</th>


                                </tr>
                            </thead>
                            <tbody>
                                {

                                    slot.map((e, i) => {
                                        return (
                                            <>
                                                <tr key={i}>
                                                    <td>{i + 1}</td>
                                                    <td>{e.slotId}</td>
                                                    <td>{e.floorNumber}</td>
                                                    <td>{e.slotNumber}</td>
                                                    <div className='justify-content-center d-flex'>
                                                        <ButtonComponent1 fno={e.floorNumber} vname={vehicleName} vplate={plate} sno={e.slotNumber} sid={e.slotId} uid={localStorage.getItem('id')} vid={vid} />
                                                    </div>
                                                </tr>


                                            </>
                                        )
                                    })
                                }


                            </tbody>

                        </Table>

                    </Fragment>
                </Modal.Body>

                <Modal.Footer>
                    <Button variant="danger" onClick={handleCloseAvailabelSlotModal}>
                        Close
                    </Button>

                </Modal.Footer>
            </Modal>



                        //modal 3

            <Modal dialogClassName="custom-modal-style modal-width" show={showReservations} onHide={handleCloseReservations}>

                <Modal.Header >
                    <Modal.Title>Your Reservations</Modal.Title>
                </Modal.Header>
                <Modal.Body><b>These are Your Upcoming Reservations!!!</b> <br />
                    <Fragment>
                        <Table striped bordered hover>
                            <thead>
                                <tr>
                                    <th>S.No</th>

                                    <th>Vehicle Name</th>
                                    <th>Vehicle Plate Number</th>

                                    <th>In Time</th>
                                    <th>Out Time</th>
                                    <th>SLot Number</th>


                                </tr>
                            </thead>
                            <tbody>
                                {

                                    reservation.map((e, i) => {
                                        return (
                                            <>
                                                <tr key={i}>
                                                    <td>{i + 1}</td>

                                                    <td>{e.vehicleVehicleDescription}</td>
                                                    <td>{e.vehicleVehiclePlateNumber}</td>
                                                    <td>{"Date : " + e.reservationStartTime.substring(0, 10) + " | " + "Time : " + e.reservationStartTime.substring(11, 16) + " HRS"}</td>
                                                    <td>{"Date : " + e.reservationEndTime.substring(0, 10) + " | " + "Time : " + e.reservationEndTime.substring(11, 16) + " HRS"}</td>
                                                    <td>{e.slotSlotNumber}</td>
                                                </tr>


                                            </>
                                        )
                                    })
                                }
                                <br></br>

                            </tbody>

                        </Table>

                    </Fragment>
                </Modal.Body>

                <Modal.Footer>
                    <Button variant="danger" onClick={handleCloseReservations}>
                        Close
                    </Button>

                </Modal.Footer>
            </Modal>


        </div>
        </>
    )
}
export default Test;