﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GarageMark1.DAL.Entities
{
    public partial class TblVehicle
    {
        public TblVehicle()
        {
            TblReservations = new HashSet<TblReservation>();
        }
        [Key]
        public int VehicleId { get; set; }
        public string VehiclePlateNumber { get; set; } = null!;
        public string? VehicleDescription { get; set; }
        public int VehicleOwnerId { get; set; }

        public virtual TblUser VehicleOwner { get; set; } = null!;
        public virtual ICollection<TblReservation> TblReservations { get; set; }
    }
}
