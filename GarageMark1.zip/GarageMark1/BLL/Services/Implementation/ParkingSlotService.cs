﻿using AutoMapper;
using GarageMark1.BLL.DTOs.ParkingSlot;
using GarageMark1.BLL.DTOs.Reservation;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories.Interfaces;

namespace GarageMark1.BLL.Services.Implementation
{
    public class ParkingSlotService : IParkingSlotService
    {
        private readonly IRepositoryWrapper repositoryWrapper;
        private readonly IMapper mapper;

        public ParkingSlotService(IRepositoryWrapper repositoryWrapper, IMapper mapper)
        {
            this.repositoryWrapper = repositoryWrapper;
            this.mapper = mapper;
        }

        public async Task<ParkingSlotResponseDTO> Add(ParkingSlotRequestDTO requestDTO)
        {
            var product = mapper.Map<TblParkingSlot>(requestDTO);
            var productResponse = await repositoryWrapper.ParkingSlotRepository.CreateAsync(product);
            await repositoryWrapper.SaveAsync();
            var result = mapper.Map<ParkingSlotResponseDTO>(productResponse);
            return result;
        }

        public async Task<bool> Delete(int id)
        {
            var data = await repositoryWrapper.ParkingSlotRepository.GetById(id);


            var res = mapper.Map<TblParkingSlot>(data);
            if (res != null)
            {
                await repositoryWrapper.ParkingSlotRepository.DeleteAsync(data);
                await repositoryWrapper.SaveAsync();
                return true;

            }
            else
            {
                return false;
            }


        }

        public Task<IEnumerable<ParkingSlotResponseDTO>> GetAll()
        {
            throw new NotImplementedException();
        }

        public async Task<ParkingSlotResponseDTO> GetById(int id)
        {
            var data = await repositoryWrapper.ParkingSlotRepository.GetById(id);
            var res = mapper.Map<ParkingSlotResponseDTO>(data);
            return res;
        }

        public async Task<ParkingSlotResponseDTO> Update(int id, ParkingSlotRequestDTO res)
        {
            var f = mapper.Map<TblParkingSlot>(res);
            f.SlotId = id;
            var v = await repositoryWrapper.ParkingSlotRepository.UpdateAsync(id, f);
            await repositoryWrapper.SaveAsync();
            var k = mapper.Map<ParkingSlotResponseDTO>(v);

            return k;
        }
    }
}
