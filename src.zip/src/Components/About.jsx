import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const About = () => {
    return (
        <div className="container about">
            <h1 className="my-4">About Us</h1>
            <p className="lead">
                Welcome to our Parking Slot Management System. We are dedicated to providing you with the most seamless parking experience.
            </p>
            <p>
                Our system allows you to reserve parking slots in advance, ensuring that you never have to worry about finding a parking spot again. We understand how valuable your time is, and our goal is to make parking as quick and easy as possible.
            </p>
            <p>
                We are constantly working to improve our services and would love to hear any feedback or suggestions you may have.
            </p>
            <p>
                Thank you for choosing our Parking Slot Management System.
            </p>
        </div>
    );
};

export default About;