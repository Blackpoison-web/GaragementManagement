﻿namespace GarageMark1.DAL.Repositories.Interfaces
{
    public interface IRepositoryWrapper
    {
        public IVehicleRepository VehicleRepository { get; set; }
        public IUserRepository UserRepository { get; set; }
        public IReservationRepository ReservationRepository { get; set; }
        public IParkingSlotRepository ParkingSlotRepository { get; set; }
        Task<int> SaveAsync();
    }

}
