
import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import App from './App';
import './App.css';
import { useNavigate } from 'react-router-dom';
const ButtonComponent1 = (props) => {
  const navigate=new useNavigate()
  const [isActive, setIsActive] = useState(false);
  const[id,setid]=useState(props.uid)
  const[vid,setvid]=useState(props.vid)
  const[sid,setsid]=useState(props.sid)
  const[fno,setfno]=useState(props.fno)
  const[sno,setsno]=useState(props.sno)
  const [vname,setvname]=useState(props.vname)
  const data1 = { userid: id, vehicleid: vid ,slotid: sid ,
  fno:fno,
  sno: sno,
  vname: vname,
  vplate: props.vplate
  };
  const handleButtonClick = () => {
    setIsActive(!isActive);
    console.log(props.data)
    navigate("/date",{state: data1})
  };

  return (
    
      <button
        type="button"
        className={`btn  btn-outline-success `}
        onClick={handleButtonClick}
      >
        Select
      </button>
    
  );
};

export default ButtonComponent1;
