﻿using AutoMapper;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.DTOs.Vehicle;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories.Interfaces;

namespace GarageMark1.BLL.Services.Implementation
{
    public class UserService : IUserService
    {
        private readonly IRepositoryWrapper repositoryWrapper;
        private readonly IMapper mapper;

        public UserService(IRepositoryWrapper repositoryWrapper, IMapper mapper)
        {
            this.repositoryWrapper = repositoryWrapper;
            this.mapper = mapper;
        }

        public async Task<UserResponseDTO> Add(UserRequestDTO requestDTO)
        {
            var product = mapper.Map<TblUser>(requestDTO);
            var productResponse = await repositoryWrapper.UserRepository.CreateAsync(product);
            await repositoryWrapper.SaveAsync();
            var result = mapper.Map<UserResponseDTO>(productResponse);
            return result;
        }

    

        public Task<IEnumerable<UserResponseDTO>> GetAll()
        {
            throw new NotImplementedException();
        }

        public async Task<UserResponseDTO> GetById(int id)
        {
            var data = await repositoryWrapper.UserRepository.GetById(id);
            var res=mapper.Map<UserResponseDTO>(data);
            return res;
        }
        public async Task<bool> Delete(int id)
        {
            var data = await repositoryWrapper.UserRepository.GetById(id);


            var res = mapper.Map<TblUser>(data);
            if (res != null)
            {
                await repositoryWrapper.UserRepository.DeleteAsync(data);
                await repositoryWrapper.SaveAsync();
                return true;

            }
            else
            {
                return false;
            }


        }

        public async Task<UserResponseDTO> Update(int id, UserRequestDTO res)
        {
            var f = mapper.Map<TblUser>(res);
            f.UserId= id;
            var v = await repositoryWrapper.UserRepository.UpdateAsync(id, f);
            await repositoryWrapper.SaveAsync();
            var k = mapper.Map<UserResponseDTO>(v);

            return k;
        }
    }
}
