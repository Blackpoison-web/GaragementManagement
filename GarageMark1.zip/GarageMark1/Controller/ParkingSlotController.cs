﻿using AutoMapper;
using GarageMark1.BLL.DTOs.ParkingSlot;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GarageMark1.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParkingSlotController : ControllerBase
    {
        private readonly IParkingSlotService ParkingSlotService;
        private readonly IMapper mapper;
        private readonly IRepositoryWrapper repository;
        public ParkingSlotController(IParkingSlotService productService, IMapper mapper, IRepositoryWrapper repositoryg)
        {
            this.ParkingSlotService = productService;
            this.mapper = mapper;
            this.repository = repositoryg;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var products = await this.repository.ParkingSlotRepository.GetAllAsync();

            var result = mapper.Map<IEnumerable<ParkingSlotResponseDTO>>(products);


            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> Post(ParkingSlotRequestDTO v)
        {
            var result = await this.ParkingSlotService.Add(v);
            return Ok(result);
        }
        [HttpGet("id")]
        public async Task<IActionResult> GetbyId(int id)
        {
            var result = await this.ParkingSlotService.GetById(id);
            return Ok(result);
        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await this.ParkingSlotService.Delete(id);
            if (data == true)
            {
                return Ok("the data is deleted");
            }
            else
            {
                return NotFound();
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> EditUser(int id, ParkingSlotRequestDTO v)
        {

            await this.ParkingSlotService.Update(id, v);
            return Ok(v);
        }
    }
}
