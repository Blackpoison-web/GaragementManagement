﻿using GarageMark1.DAL.Entities;

namespace GarageMark1.DAL.Repositories.Interfaces
{
    public interface IUserRepository : IBaseRepository<TblUser> { }
}
