﻿using GarageMark1.DAL.DBContext;
using GarageMark1.DAL.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace GarageMark1.DAL.Repositories.Implementations
{

    public abstract class RepositoryBase<T> : IBaseRepository<T> where T : class
        {
            private readonly GarageContext dbContext;

            private readonly DbSet<T> dbSet;

            public RepositoryBase(GarageContext dbContext)
            {
                this.dbContext = dbContext;
                this.dbSet = this.dbContext.Set<T>();
            }

            public async Task<T> CreateAsync(T entity)
            {
                var result = await this.dbSet.AddAsync(entity);
                return result.Entity;
            }

            public async Task<bool> DeleteAsync(T entity)
            {

                var result = this.dbSet.Remove(entity);

                return await Task.FromResult(result.Entity is not null);
            }

            public async Task<IEnumerable<T>> GetAllAsync(params string[] navsToInclude)
            {
                IQueryable<T> query = this.dbSet;
                if (navsToInclude.Length > 0)
                {
                    foreach (var item in navsToInclude)
                    {
                        query = query.Include(item);
                    }
                }
                var result = query.AsEnumerable();
                return await Task.FromResult(result);
            }

            public async Task<IEnumerable<T>> GetByCondition(Expression<Func<T, bool>> condition)
            {
                var result = this.dbSet.Where(condition);
                return await Task.FromResult(result.AsEnumerable());
            }

            public async Task<T?> GetById(int id)
            {
                return await this.dbSet.FindAsync(id);
            }

          /*  public async Task<T> UpdateAsync(T entity)
            {
                var result = this.dbSet.Update(entity);
                return await Task.FromResult(result.Entity);
            }*/
          public async Task<T> UpdateAsync(int id,T  entity)
        {
            var dbEntity = await this.dbSet.FindAsync(id);
            if (dbEntity == null)
                throw new KeyNotFoundException($"Resource with Id:{id} not Found");
            dbContext.Entry(dbEntity).CurrentValues.SetValues(entity);
            return entity;
        }
        
    }
    
}
