import Table from 'react-bootstrap/Table';
import { useState } from 'react';
import axios from 'axios';
import photo from './Assets/garage1.avif'
import { ToastContainer, toast } from 'react-toastify';
import { useEffect } from 'react';
const Reservation = () => {
    const [data, setData] = useState([])
    const getData = () => {
        if(localStorage.getItem("id")==71){
        axios.get('https://localhost:7170/api/Reservation').then((res) => {
            setData(res.data)
        }).catch((e) => {
            console.log(e)
        })
    }
    }
    useEffect(() => {
        getData();
    }, [])
    const handleDelete = (id, k) => {
        k.preventDefault()
        axios.delete(`https://localhost:7170/api/Reservation?id=${id}`).then((res) => {
            console.log(res.status)
            toast.success("Reservation Deleted")
            getData()
        }).catch((e) => {
            console.log(e)
        })
    }
    const back={
        backgroundImage: `url(${photo})`,
        backgroundRepeat: 'none'
    }
    return (
        <>
            <ToastContainer />
           
            <div className="login3" style={back}>

                <Table striped>
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>User Name</th>
                            <th>Vehicle Name</th>
                            <th>Vehicle Number</th>
                            <th>In Time</th>
                            <th>Out Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {

                            data.map((e, i) => {
                                return (
                                    <>
                                        <tr key={i}>
                                            <td>{i + 1}</td>
                                            <td>{e.userUsername}</td>
                                            <td>{e.vehicleVehicleDescription}</td>
                                            <td>{e.vehicleVehiclePlateNumber}</td>
                                            <td>{"Date : "+e.reservationStartTime.substring(0,10)+" "+"Time : "+e.reservationStartTime.substring(11,16)+" HRS"}</td>
                                            <td>{"Date : "+e.reservationEndTime.substring(0,10)+" "+"Time : "+e.reservationEndTime.substring(11,16)+" HRS"}</td>
                                            <td><button onClick={(k) => { handleDelete(e.reservationId, k) }} className="btn btn-danger">Delete</button></td>

                                        </tr>


                                    </>
                                )
                            })
                        }


                    </tbody>
                </Table>
            </div>
        </>
    )
}
export default Reservation;
