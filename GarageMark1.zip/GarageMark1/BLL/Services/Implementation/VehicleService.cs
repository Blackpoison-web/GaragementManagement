﻿using AutoMapper;
using GarageMark1.BLL.DTOs.User;
using GarageMark1.BLL.DTOs.Vehicle;
using GarageMark1.BLL.Services.Interfaces;
using GarageMark1.DAL.DBContext;
using GarageMark1.DAL.Entities;
using GarageMark1.DAL.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlTypes;
using System.Runtime.InteropServices;

namespace GarageMark1.BLL.Services.Implementation
{
    public class VehicleService : IVehicleService
    {
        private readonly IRepositoryWrapper repositoryWrapper;
        private readonly GarageContext _g;
        private readonly IMapper mapper;

        public VehicleService(IRepositoryWrapper repositoryWrapper, IMapper mapper)
        {
            this.repositoryWrapper = repositoryWrapper;
            this.mapper = mapper;
            
        }

        public async Task<VehicleResponseDTO> Add(VehicleRequestDTO requestDTO)
        {
            var product = mapper.Map<TblVehicle>(requestDTO);
            var productResponse = await repositoryWrapper.VehicleRepository.CreateAsync(product);
            await repositoryWrapper.SaveAsync();
            var result = mapper.Map<VehicleResponseDTO>(productResponse);
            return result;
        }
        public async Task<VehicleResponseDTO> Update(int id,VehicleRequestDTO res)
        {
            var f=mapper.Map<TblVehicle>(res);
            f.VehicleId = id;
           var v= await repositoryWrapper.VehicleRepository.UpdateAsync(id,f);
            await repositoryWrapper.SaveAsync();
            var k = mapper.Map<VehicleResponseDTO>(v);
           
            return k;
        }
        public async Task<bool> Delete(int id)
        {
            var data = await repositoryWrapper.VehicleRepository.GetById(id);

            
            var res = mapper.Map<TblVehicle>(data);
            if(res != null)
            {
                await repositoryWrapper.VehicleRepository.DeleteAsync(data);
                await repositoryWrapper.SaveAsync();
                return true;

            }
            else
            {
                return false;
            }
           
           
        }

        public Task<IEnumerable<VehicleResponseDTO>> GetAll()
        {
            throw new NotImplementedException();
        }
        public async Task<string> GetName1(int id)
        {

            return await this.repositoryWrapper.VehicleRepository.GetName(id);
        }
        public async Task<List<string>> GetVehicleNames(int id)
        {
            return await this.repositoryWrapper.VehicleRepository.GetVehicleNames(id);

        }
        public async Task<VehicleResponseDTO> GetById(int id)
        {
            var data = await repositoryWrapper.VehicleRepository.GetById(id);
            var res = mapper.Map<VehicleResponseDTO>(data);
            return res;
        }

       /* public Task<VehicleResponseDTO> Update(VehicleRequestDTO requestDTO)
        {
            throw new NotImplementedException();
        }*/
    }
}
