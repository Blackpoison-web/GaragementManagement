﻿namespace GarageMark1.BLL.DTOs.ParkingSlot
{
    public class ParkingSlotResponseDTO
    {
        public int SlotId { get; set; }
        public int FloorNumber { get; set; }
        public string SlotNumber { get; set; } = null!;
        public bool IsReserved { get; set; }
    }
}
