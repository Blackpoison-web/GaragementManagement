import Table from 'react-bootstrap/Table';
import { useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import { useEffect } from 'react';
import photo from './Assets/garage1.avif'
const User = () => {
  const [data, setData] = useState([])
  const getData = () => {
    if(localStorage.getItem("id")==71){
    axios.get('https://localhost:7170/api/User').then((res) => {
      setData(res.data)
    }).catch((e) => {
      console.log(e)
    })
  }
  }
  useEffect(() => {
    getData();
  }, [])
  const handleDelete = (id, k) => {
    k.preventDefault()
   
    axios.delete(`https://localhost:7170/api/User?id=${id}`).then((res) => {
      console.log(res.status)
      toast.success("User Deleted")
      getData()
    }).catch((e) => {
      console.log(e)
      toast.error("User is Having Reservation")
    })
  
  }
  const back={
    backgroundImage: `url(${photo})`,
    backgroundRepeat: 'none'
}
  return (
    <>
      <ToastContainer />
      
      
      <div className="login3" style={back}>
      <span className=" justify-content-center text-white d-flex"><h1 >User Details</h1></span> <br></br>
          <Table>
          <thead>
            <tr>
              <th>S.No</th>
              <th>UserId</th>
              <th>User Name</th>
              <th>Email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {

              data.map((e, i) => {
                return (
                  <>
                    <tr key={i}>
                      <td>{i + 1}</td>
                      <td>{e.userId}</td>
                      <td>{e.username}</td>
                      <td>{e.email}</td>
                      <td><button onClick={(k) => { handleDelete(e.userId, k) }} className="btn btn-danger">Delete</button></td>

                    </tr>


                  </>
                )
              })
            }


          </tbody>
        </Table>
      </div>
    </>
  )
}
export default User;
